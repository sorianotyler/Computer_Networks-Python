Tyler Soriano 1545385
CSE 150 
Lab3 README 

Files: 
lab3.pdf
lab3controller.py
README

lab3.pdf:
    This file holds the screenshots and explainations for all of the questions asked in this lab. I have added detailed screenshots and provided explainations
    to why i believe my answers to be correct. 

lab3controller.py:
    This file holds the code to my firewall. I based it off of the lab manual instructions and used a reasource explaning how to create switches. I provided
    all of the resources I used both to complete the explainations and the code in lab3.pdf. I believe this code does exactly what was asked. 

README:
    This is the file you are currently reading which explains what each of the file contains. It also show you where you can find my references and resources
    I used to complete this lab. 