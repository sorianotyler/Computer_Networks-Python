Tyler Soriano 
CSE 150
README 

table of contents: 
    1. finalcontroller_skel.py 
    2. final_skel.py 
    3. project.pdf
    4. README

finalcontroller_skel:
    This file houses my controller. This was the most difficult aspect of the assignment. I went to the TA Wil and he helped me develope my sudo-code.
He recomended to me to create functions so I can clearly see what was going on and to debug better. This helped me with my ICMP packets and my ARP Packets. 
I was still stuck on TCP packets so I had gotten help from the TA Hoafan. She helped me with the logic for the TCP packets where I implemeneted the IF
TCP section of code. This allowed me to direct TCP traffic correctly. Overall, I was able to get the correct output using the code from the previous lab as
refference.

final_skel:
    This is the topology aspect of this assignment. I followed the directions and logic and used the lab3.py as refference. I tried to make it as clear as 
possible. I label as much as I need to understand the topology to correctly implemenet it into the controller.

project.pdf:
    This houses all of the explainations and the screenshots of why this project is done correctly. I use the pingall, iperf, and dpctl dump-flows command 
to show the proof. All of the commands succeed and I was able to show why my code works. I also offer explainations. 

README: 
    The README is complete and provides detailed descriptions of what help and resources I used to complete the lab. 